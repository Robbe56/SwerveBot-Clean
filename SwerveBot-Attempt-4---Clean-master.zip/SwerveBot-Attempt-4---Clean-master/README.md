Offseason swerve drive
